function addStudent() {
    
    const name = document.getElementById("studentName").value;
    const className = document.getElementById("Class").value;
    const Address = document.getElementById("Address").value;
    const ConatctNo = document.getElementById("contact no").value;

    
    if (name === "" || className === "" || Address === "" || ConatctNo === "") {
        alert("Please fill out all fields.");
        return;
    }

    
    const table = document.getElementById("studentTable");
    const row = table.insertRow(-1);
    row.insertCell(0).innerText = name;
    row.insertCell(1).innerText = className;
    row.insertCell(2).innerText = Address;
    row.insertCell(3).innerText = ConatctNo;

   
    const actionCell = row.insertCell(4);

    const resetBtn = document.createElement("button");
    resetBtn.innerText = "Reset";
    resetBtn.classList.add("action-button", "reset");
    resetBtn.onclick = () => resetRow(row, name, className, Address, ConatctNo);

    const deleteBtn = document.createElement("button");
    deleteBtn.innerText = "Delete";
    deleteBtn.classList.add("action-button", "delete");
    deleteBtn.onclick = () => deleteRow(row);

    actionCell.appendChild(resetBtn);
    actionCell.appendChild(deleteBtn);

    
    document.getElementById("studentName").value = "";
    document.getElementById("Class").value = "";
    document.getElementById("Address").value = "";
    document.getElementById("contact no").value = "";
}

function resetRow(row, name, className, Address , ConatctNo) {
    row.cells[0].innerText = name;
    row.cells[1].innerText = className;
    row.cells[2].innerText = Address;
    row.cells[3].innerText = ConatctNo;
}

function deleteRow(row) {
    row.remove();
}
